const state = {
  models: [],
  selectedModels: new Set(),
  lastResults: [],
  questionCount: 0,
  chunkCount: 0,
};

const benchmarkQuestions = [
  "How many days of annual leave do full-time employees receive?",
  "Which days are designated office days for eligible hybrid employees?",
  "How quickly should a lost company laptop be reported?",
  "What is the reimbursement submission deadline?",
  "When must new employees complete security training?",
];

const $ = (selector) => document.querySelector(selector);
const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (char) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
}[char]));

async function api(path, options = {}) {
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = payload.detail || `Request failed (${response.status})`;
    throw new Error(Array.isArray(detail) ? detail.map((item) => item.msg).join(", ") : detail);
  }
  return payload;
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("visible");
  window.clearTimeout(showToast.timeout);
  showToast.timeout = window.setTimeout(() => toast.classList.remove("visible"), 4500);
}

function modelInitials(name) {
  const parts = name.split(/[-/:]/).filter(Boolean);
  return (parts.length > 1 ? parts.slice(0, 2).map((part) => part[0]) : [name[0] || "M"])
    .join("").toUpperCase();
}

function renderModels() {
  const grid = $("#modelGrid");
  if (!state.models.length) {
    grid.innerHTML = '<div class="loading-state">No models are configured. Set OPENAI_MODEL or RAG_MODELS in backend/.env.</div>';
    return;
  }
  grid.innerHTML = state.models.map((model, index) => {
    const checked = state.selectedModels.has(model.id);
    return `<label class="model-card${checked ? " selected" : ""}">
      <input type="checkbox" data-model="${escapeHtml(model.id)}" ${checked ? "checked" : ""} aria-label="Select ${escapeHtml(model.name)}">
      <span class="model-symbol">${escapeHtml(modelInitials(model.name))}</span>
      <span class="model-copy"><span class="model-title-line"><span class="model-title">${escapeHtml(model.name)}</span><span class="model-badge">${index === 0 ? "Default" : "Configured"}</span></span>
      <span class="model-description">${index === 0 ? "Configured RAG model" : "Additional configured model"}</span></span>
    </label>`;
  }).join("");
  grid.querySelectorAll("input[type=checkbox]").forEach((input) => {
    input.addEventListener("change", () => {
      if (input.checked && state.selectedModels.size >= 3) {
        input.checked = false;
        showToast("Select up to 3 models.");
        return;
      }
      if (input.checked) state.selectedModels.add(input.dataset.model);
      else state.selectedModels.delete(input.dataset.model);
      input.closest(".model-card").classList.toggle("selected", input.checked);
      updateSelectionCount();
    });
  });
  updateSelectionCount();
}

function updateSelectionCount() {
  $("#selectionCount").textContent = `${state.selectedModels.size} / 3 selected`;
}

function selectedModels() {
  return state.models.filter((model) => state.selectedModels.has(model.id)).map((model) => model.id);
}

function setBusy(button, busy, label) {
  button.disabled = busy;
  button.dataset.label ||= button.innerHTML;
  button.innerHTML = busy ? `<span class="spinner"></span> ${label}` : button.dataset.label;
}

function modelSymbol(modelId) {
  return `<span class="model-symbol">${escapeHtml(modelInitials(modelId))}</span>`;
}

function renderAnswers(results) {
  $("#answerList").innerHTML = results.map((result) => {
    const failed = Boolean(result.error);
    const timing = result.latency_ms == null ? "—" : `${(result.latency_ms / 1000).toFixed(2)} s`;
    return `<article class="answer-card">
      <div class="answer-head"><span class="answer-model">${modelSymbol(result.model)}<span>${escapeHtml(result.model)}</span></span><span class="latency-chip">◷ ${timing}</span></div>
      <div class="answer-text${failed ? " answer-error" : ""}">${escapeHtml(result.error || result.answer || "The model returned an empty answer.")}</div>
    </article>`;
  }).join("");
  const uniqueSources = new Map();
  for (const result of results) {
    for (const source of result.sources || []) uniqueSources.set(source.id, source);
  }
  $("#sourcesCount").textContent = uniqueSources.size ? `(${uniqueSources.size})` : "";
  $("#sourcesList").innerHTML = [...uniqueSources.values()].map((source) => `
    <article class="source-item"><div class="source-meta"><span>${escapeHtml(source.id)}</span><span>distance ${escapeHtml(source.distance)}</span></div>
    <p>${escapeHtml(source.text)}</p></article>`).join("") || '<p class="form-hint">No source chunks were returned.</p>';
  $("#sourcesPanel").open = false;
}

function renderPerformance(results, questionCount = 1) {
  state.lastResults = results;
  state.questionCount += questionCount;
  const successful = results.filter((result) => !result.error && Number.isFinite(result.latency_ms));
  const fastest = successful.reduce((best, item) => !best || item.latency_ms < best.latency_ms ? item : best, null);
  const average = successful.length
    ? successful.reduce((sum, item) => sum + item.latency_ms, 0) / successful.length
    : null;
  $("#bestLatency").textContent = fastest ? `${(fastest.latency_ms / 1000).toFixed(2)} s` : "—";
  $("#bestModel").textContent = fastest ? fastest.model : "No successful responses";
  $("#averageLatency").textContent = average == null ? "—" : `${(average / 1000).toFixed(2)} s`;
  $("#questionTotal").textContent = String(state.questionCount);
  $("#chunkTotal").textContent = `${state.chunkCount} indexed chunks`;
  $("#resultsSubtitle").textContent = questionCount > 1
    ? `Results across ${questionCount} benchmark questions.`
    : "Performance for the latest question.";
  $("#resultsTable").innerHTML = results.length ? results.map((result) => {
    const failed = Boolean(result.error);
    return `<tr><td class="table-model">${escapeHtml(result.model)}</td><td>${result.latency_ms == null ? "—" : `${(result.latency_ms / 1000).toFixed(2)} s`}</td><td>${result.sources?.length ?? "—"}</td><td><span class="table-status${failed ? " failed" : ""}">${failed ? "● Failed" : "● Complete"}</span></td></tr>`;
  }).join("") : '<tr class="table-empty"><td colspan="4">No results returned.</td></tr>';
  renderChart("#latencyChart", successful, (item) => item.latency_ms / 1000, (value) => `${value.toFixed(2)}s`, "latency");
  renderChart("#sourceChart", successful, (item) => item.sources?.length || 0, (value) => `${value}`, "sources");
}

function renderChart(selector, results, valueFor, format, mode) {
  const chart = $(selector);
  if (!results.length) {
    chart.innerHTML = `<div class="chart-empty">${mode === "latency" ? "Run a question to compare response times." : "Source counts will appear here."}</div>`;
    return;
  }
  const values = results.map(valueFor);
  const max = Math.max(...values, mode === "sources" ? 1 : .01);
  chart.innerHTML = results.map((result, index) => {
    const value = values[index];
    const percent = Math.max(value > 0 ? 5 : 0, (value / max) * 84);
    return `<div class="chart-column"><span class="bar-value">${format(value)}</span><span class="bar-fill" style="height:${percent}%"></span><span class="bar-label">${escapeHtml(result.model)}</span></div>`;
  }).join("");
}

async function askModels() {
  const question = $("#questionInput").value.trim();
  const models = selectedModels();
  if (models.length === 0) return showToast("Select at least one model first.");
  if (question.length < 3) return showToast("Enter a question with at least 3 characters.");
  const button = $("#askButton");
  setBusy(button, true, "Asking models…");
  try {
    const response = await api("/api/ask", {
      method: "POST",
      body: JSON.stringify({ question, models }),
    });
    renderAnswers(response.results);
    renderPerformance(response.results);
    if (response.results.every((result) => result.error)) {
      showToast(response.results[0].error);
    } else if (response.results.some((result) => result.error)) {
      showToast("Some selected models failed. See the response cards for details.");
    }
  } catch (error) {
    showToast(error.message);
  } finally {
    setBusy(button, false);
  }
}

function renderBenchmarkQuestions() {
  $("#benchmarkQuestions").innerHTML = benchmarkQuestions.map((question, index) => `
    <div class="benchmark-question"><span class="question-number">${index + 1}</span><span>${escapeHtml(question)}</span></div>`).join("");
}

async function runBenchmark() {
  const models = selectedModels();
  if (models.length === 0) return showToast("Select at least one model first.");
  const button = $("#runBenchmarkButton");
  setBusy(button, true, "Running benchmark…");
  $("#benchmarkResults").classList.add("hidden");
  try {
    const response = await api("/api/benchmark", {
      method: "POST",
      body: JSON.stringify({ models }),
    });
    const results = response.results || [];
    renderPerformance(results, benchmarkQuestions.length);
    $("#benchmarkResults").innerHTML = benchmarkQuestions.map((question) => {
      const answers = results.filter((result) => result.question === question);
      return `<article class="benchmark-result"><h4>${escapeHtml(question)}</h4>${answers.map((answer) => `
        <p><strong>${escapeHtml(answer.model)}</strong> · ${answer.error ? escapeHtml(answer.error) : `${(answer.latency_ms / 1000).toFixed(2)} s · ${answer.sources?.length || 0} sources`}<br>${escapeHtml(answer.answer || "")}</p>`).join("")}</article>`;
    }).join("");
    $("#benchmarkResults").classList.remove("hidden");
    if (results.length && results.every((result) => result.error)) showToast(results[0].error);
    else if (results.some((result) => result.error)) showToast("Some benchmark requests failed. Their errors are shown below.");
  } catch (error) {
    showToast(error.message);
  } finally {
    setBusy(button, false);
  }
}

async function loadStatus() {
  try {
    const [health, modelData] = await Promise.all([api("/api/health"), api("/api/models")]);
    state.models = modelData.models || [];
    state.selectedModels = new Set(state.models.slice(0, Math.min(3, state.models.length)).map((model) => model.id));
    state.chunkCount = health.chunk_count || 0;
    $("#documentName").textContent = health.document || "No document found";
    $("#sidebarDocument").textContent = health.document || "No document found";
    $("#documentCheck").classList.toggle("pending", !health.index_ready || !health.ai_configured);
    $("#documentCheck").textContent = health.index_ready ? "✓" : "!";
    const isReady = health.index_ready && health.ai_configured;
    $("#connectionDot").className = `connection-dot ${isReady ? "connected" : "disconnected"}`;
    $("#connectionLabel").textContent = isReady ? "Backend connected" : "Setup required";
    $("#connectionDetail").textContent = !health.index_ready
      ? "Run 05_store_in_chroma.py"
      : !health.ai_configured ? "Configure OPENAI_API_KEY" : `${health.chunk_count} chunks indexed`;
    $("#chunkTotal").textContent = `${state.chunkCount} indexed chunks`;
    renderModels();
    if (!health.index_ready) showToast("No indexed collection found. Run backend/05_store_in_chroma.py first.");
    else if (!health.ai_configured) showToast("Configure OPENAI_API_KEY in backend/.env to generate answers.");
  } catch (error) {
    $("#connectionDot").className = "connection-dot disconnected";
    $("#connectionLabel").textContent = "Backend unavailable";
    $("#connectionDetail").textContent = "Start the API server";
    $("#documentName").textContent = "Backend unavailable";
    $("#sidebarDocument").textContent = "Backend unavailable";
    showToast(error.message);
  }
}

async function loadLogs() {
  const container = $("#logList");
  container.innerHTML = '<div class="loading-state">Loading recent activity…</div>';
  try {
    const response = await api("/api/logs");
    const entries = response.logs || [];
    container.innerHTML = entries.length ? entries.map((entry) => {
      const date = new Date(entry.timestamp);
      const timestamp = Number.isNaN(date.getTime()) ? entry.timestamp : date.toLocaleString();
      return `<article class="log-item"><div><div class="log-question">${escapeHtml(entry.question)}</div><div class="log-meta"><span>${escapeHtml((entry.models || []).join(", "))}</span><span>${entry.successful} succeeded · ${entry.failed} failed</span></div></div><span class="log-meta">${escapeHtml(timestamp)} · ${(entry.latency_ms / 1000).toFixed(2)} s</span></article>`;
    }).join("") : '<div class="empty-state"><strong>No activity yet</strong><span>Your recent requests will show here.</span></div>';
  } catch (error) {
    container.innerHTML = `<div class="empty-state"><strong>Could not load request logs</strong><span>${escapeHtml(error.message)}</span></div>`;
  }
}

function setPage(page) {
  document.querySelectorAll(".page-view").forEach((view) => view.classList.remove("active"));
  const target = page === "playground" ? $("#playgroundPage") : page === "benchmark" ? $("#benchmarkPage") : $("#logsPage");
  target.classList.add("active");
  document.querySelectorAll(".nav-link").forEach((link) => link.classList.toggle("active", link.dataset.page === page));
  if (page === "logs") loadLogs();
}

function setQueryTab(tab) {
  const isAsk = tab === "ask";
  $("#askTab").classList.toggle("active", isAsk);
  $("#benchmarkTab").classList.toggle("active", !isAsk);
  $("#askTab").setAttribute("aria-selected", String(isAsk));
  $("#benchmarkTab").setAttribute("aria-selected", String(!isAsk));
  $("#askContent").classList.toggle("hidden", !isAsk);
  $("#benchmarkContent").classList.toggle("hidden", isAsk);
}

document.querySelectorAll(".nav-link").forEach((link) => link.addEventListener("click", () => setPage(link.dataset.page)));
document.querySelectorAll("[data-go-playground]").forEach((button) => button.addEventListener("click", () => setPage("playground")));
$("#askTab").addEventListener("click", () => setQueryTab("ask"));
$("#benchmarkTab").addEventListener("click", () => setQueryTab("benchmark"));
$("#askButton").addEventListener("click", askModels);
$("#runBenchmarkButton").addEventListener("click", runBenchmark);
$("#questionInput").addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key === "Enter") askModels();
});
$("#refreshLogs").addEventListener("click", loadLogs);
$("#mobileMenu").addEventListener("click", () => {
  document.querySelector(".mobile-header").classList.toggle("open");
  document.querySelector(".sidebar")?.classList.toggle("mobile-visible");
});
renderBenchmarkQuestions();
loadStatus();
