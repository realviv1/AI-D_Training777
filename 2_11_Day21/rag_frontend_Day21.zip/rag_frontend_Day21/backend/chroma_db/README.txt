ChromaDB will create its database files in this folder when you run 05_store_in_chroma.py.
There is no database server to start.
