--C1
select *
from parts
where category = 'Mechanical';


--C2
select *
from parts
where unit_price >1000 order by unit_price DESC;

--C3
select category, AVG(unit_price) as avg_price
from parts group by category;

--C4
select category, sum(stock_qty) as stock_total
from parts group by category;


--C5
select po.po_id, s.supplier_name, po.order_date, po.status
from purchase_orders po
join suppliers s on po.supplier_id = s.supplier_id;

--C6
select po.po_id, p.part_name, i.quantity, p.unit_price
from purchase_orders po
join purchase_order_items i on po.po_id = i.po_id
join parts p on i.part_id = p.part_id;

--c7
select po.po_id, p.part_name, i.quantity, p.unit_price,
	   i.quantity * p.unit_price as line_total
from purchase_orders po
join purchase_order_items i on po.po.id = i.po_id
join parts p on i.part_id = p.part_id;

--c8
select s.*, po.po_id
from suppliers s left join purchase_orders po
on s.supplier_id = po.supplier_id;

--c9
select s.*
from suppliers s left join purchase_orders po
on s.supplier_id = po.supplier_id
where po.po_id is null;


--c10
create or replace view purchase_order_summary as
select po.po_id, s.supplier_name, p.part_name, i.quantity, p.unit_price, i.quantity*p.unit_price as line_total, po.status
from purchase_orders po
join suppliers s on po.supplier_id = s.supplier_id
join purchase_order_items i on po.po_id = i.po_id
join parts p on i.part_id = p.part_id;

select*from purchase_order_summary where status = 'Pending'


--c11
create function  calculate_part_discount(amount numeric)
returns numeric language plpgsql as $$
begin
	return case when amount >=2000 then amount * 0.10 else o end;
end;
$$;

--c12
create function final_part_price(amount numeric)
returns numeric language plpgsql as $$
begin 
	return amount -  calculate_part_discount(amount);
end;
$$;

--c13
create procedure  update_po_status(
	p_id int, p_status varchar(30)
)
language sql as $$
	update purchase_orders set status = p_status where po_id = p_id;
$$;
call update_po_status(1, 'Received');
select * from purchase_orders where po_id = 1;


--c14
create procedure mark_old_pending_orders()
language sql as $$
	update purchase_orders
	set status = 'Received'
	where status = 'Pending'
		and order_date < date '2026-10-04'

$$;

call mark_old_pending_orders();
select * from purchase_orders
where status = 'Received';






