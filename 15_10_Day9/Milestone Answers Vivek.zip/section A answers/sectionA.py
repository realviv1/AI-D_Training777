import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import json

#A1

df = pd.read_csv("urban_mobility.csv")
print("\nA1, First five rows")
print(df.head())

#A2
df["Energy_Per_Km"] = df["Energy_Used_kWh"]/df["Distance_Km"]
print("\nA2, Energy per Km")
print(df[["Energy_Used_kWh", "Distance_Km", "Energy_per_Km"]])

#A3
print(df[
          (df["Vehicle_Type"] == "Electric van") &
          (df["Maintenance_Flag"].astype(str).str.strip().str.lower() == "Yes")
      ])

#A4
print(
    df.groupby("Vehicle_Type").agg(
        Average_Distance_km=("Distance_Km", "mean"),
        Total_Trips_count=("Trips_Count", "sum"),
    )
)

#A5
e =  df["Energy_Used_kWh"].dropna()
print(np.mean(e), np.max(e), np.min(e))

#A6
df.groupby("Vehicle_Type")["Energy_Used_kWh"].mean().plot(kind="bar")
plt.show()

#A7
with open("equipment_events.json") as f:
    events = json.load(f)

#A8
for x in events :
    print(x.get("event_id"), x.get("asset", {}).get("type"),
          x.get("asset", {}).get("site"), x.get("severity")
    if x.get("temperature", 0) > 70:
        print(x.get("actions", "'No actions recorded'."))


#A9
with open("coastal_monitoring_log.txt") as f:
    text = f.read();

print("Words:", len(text.split()));
print("Inspection", text.lower().count("inspection"))

#A10
for line in text.splitlines():
    if any(w in line.lower()) for w in ["boardwalk", "maintenance", "wind"]):
        print(line)




# State which of the three supplied files is structured, semi-structured and unstructured, and give one reason for each.
# Answer

# The structured file was CSV, semi structured file was JSON, and the unstructured file was TXT.












