import { useState } from "react";


function DeleteProduct({ productId, onDelete }) {
	const [isDeleting, setIsDeleting] = useState(false);

	async function handleDelete() {
		if (productId == null || typeof onDelete !== "function" || isDeleting) return;
		if (!window.confirm("Delete this product?")) return;

		setIsDeleting(true);
		try {
			await onDelete(productId);
		} finally {
			setIsDeleting(false);
		}
	}

	return (
		<button
			type="button"
			onClick={handleDelete}
			disabled={productId == null || typeof onDelete !== "function" || isDeleting}
			aria-label="Delete product"
		>
			{isDeleting ? "Deleting…" : "Delete"}
		</button>
	);
}

export default DeleteProduct