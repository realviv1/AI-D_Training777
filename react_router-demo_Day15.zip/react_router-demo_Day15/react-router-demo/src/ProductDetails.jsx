import {
  useParams,
  useNavigate
} from "react-router-dom";
 
import { useEffect, useState } from "react";
 
function ProductDetails() {
  const { id } = useParams();
 
  const navigate = useNavigate();
 
  const [product, setProduct] = useState(null);
 
  useEffect(() => {
    fetchProduct();
  }, []);
 
  const fetchProduct = async () => {
    const response = await fetch(
      "http://localhost:8000/products",{
        method: "GET"
      }
    );
 
    const data = await response.json();
 
    const selectedProduct = data.find(
      (p) => p.id === Number(id)
    );
 
    setProduct(selectedProduct);
  };
 
  if (!product) {
    return <h2>Loading...</h2>;
  }
 
  return (
    <div>
      <h1>Product Details</h1>
 
      <p>Product ID: {product.id}</p>
 
      <p>Name: {product.name}</p>
 
      <p>Price: ₹{product.price}</p>
 
      <p>Image: <img
      src={product.image}
      alt={product.name}
      width="200"
  /> </p>
 
      <button
        onClick={() => navigate("/products")}
      >
        Back to Products
      </button>
    </div>
  );
}
 
export default ProductDetails;