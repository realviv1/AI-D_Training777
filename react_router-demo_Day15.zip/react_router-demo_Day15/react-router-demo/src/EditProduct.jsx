import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function EditProduct() {
	const { id } = useParams();
	const navigate = useNavigate();
	const [product, setProduct] = useState({ name: "", description: "", price: "" });
	const [loading, setLoading] = useState(true);
	const [saving, setSaving] = useState(false);
	const [error, setError] = useState("");

	useEffect(() => {
		const controller = new AbortController();

		async function fetchProduct() {
			try {
				const response = await fetch(`/api/products/${id}`, {
					signal: controller.signal,
				});
				if (!response.ok) throw new Error("Unable to load product.");
				const data = await response.json();
				setProduct({
					name: data.name ?? data.title ?? "",
					description: data.description ?? "",
					price: data.price ?? "",
				});
			} catch (err) {
				if (err.name !== "AbortError") setError(err.message);
			} finally {
				if (!controller.signal.aborted) setLoading(false);
			}
		}

		fetchProduct();
		return () => controller.abort();
	}, [id]);

	function handleChange(event) {
		setProduct((current) => ({ ...current, [event.target.name]: event.target.value }));
	}

	async function handleSubmit(event) {
		event.preventDefault();
		setSaving(true);
		setError("");

		try {
			const response = await fetch(`/api/products/${id}`, {
				method: "PUT",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({ ...product, price: Number(product.price) }),
			});
			if (!response.ok) throw new Error("Unable to save product.");
			navigate(-1);
		} catch (err) {
			setError(err.message);
		} finally {
			setSaving(false);
		}
	}

	if (loading) return <p>Loading product…</p>;

	return (
		<form onSubmit={handleSubmit}>
			<h1>Edit product</h1>
			{error && <p role="alert">{error}</p>}

			<label htmlFor="name">Name</label>
			<input id="name" name="name" value={product.name} onChange={handleChange} required />

			<label htmlFor="description">Description</label>
			<textarea
				id="description"
				name="description"
				value={product.description}
				onChange={handleChange}
				rows={4}
			/>

			<label htmlFor="price">Price</label>
			<input
				id="price"
				name="price"
				type="number"
				min="0"
				step="0.01"
				value={product.price}
				onChange={handleChange}
				required
			/>

			<button type="submit" disabled={saving}>
				{saving ? "Saving…" : "Save changes"}
			</button>
		</form>
	);
}

export default EditProduct