import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
 
function Products() {
  const [products, setProducts] = useState([]);
 
  useEffect(() => {
    fetchProducts();
  }, []);
 
  const fetchProducts = async () => {
    const response = await fetch(
      "http://localhost:8000/products"
    );
 
    const data = await response.json();
 
    setProducts(data);
  };
 
  return (
    <div>
      <h1>Products</h1>
      {products.map((product) => (
  <div key={product.id}>
    <h3>{product.name}</h3>
 
    <img
      src={product.image}
      alt={product.name}
      width="200"
    />
 
    <p>₹ {product.price}</p>
 
    <Link to={`/products/${product.id}`}>
      View Details
    </Link>
  </div>
))}
     
    </div>
  );
}
 
export default Products;