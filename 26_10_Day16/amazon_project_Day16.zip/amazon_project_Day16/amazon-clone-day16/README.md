<<<<<<< HEAD
# Bamazon Marketplace

A frontend-only React marketplace practice project. It uses local sample product data and React state—there is no database, real authentication, or payment processing.

## Run locally

```sh
npm install
npm run dev
```

## Practice features

- Responsive marketplace-style storefront and product cards
- Search and category filtering
- Product detail dialog
- Cart quantities and subtotal
- Mock sign-in prompt before checkout
- Simulated order confirmation (no payment or account data is saved)

Products are defined in `src/data/products.js`. The main page and interaction state are in `src/App.jsx`; page styles are in `src/App.css` and `src/index.css`.
=======
# AI-DATA-Training
Training Repository by Vivek Sharma. 
>>>>>>> 66d2310ca52ee064a40bae3f37372eb8a394acf8
