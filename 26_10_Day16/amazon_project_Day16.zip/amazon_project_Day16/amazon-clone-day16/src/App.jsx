import { useMemo, useState } from 'react'
import { products, categories } from './data/products.js'
import './App.css'

function Icon({ name, size = 20 }) {
  const paths = {
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    pin: <><path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z" /><circle cx="12" cy="10" r="2.5" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
    cart: <><path d="M3 3h2l2.2 11.2a2 2 0 0 0 2 1.6h8.9a2 2 0 0 0 2-1.6L22 8H6" /><circle cx="10" cy="20" r="1" /><circle cx="18" cy="20" r="1" /></>,
    arrow: <><path d="M5 12h14" /><path d="m13 6 6 6-6 6" /></>,
    close: <><path d="m18 6-12 12M6 6l12 12" /></>,
    minus: <path d="M5 12h14" />,
    plus: <><path d="M12 5v14" /><path d="M5 12h14" /></>,
    star: <path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z" />,
    menu: <><path d="M4 6h16M4 12h16M4 18h16" /></>,
    check: <path d="m5 12 4 4L19 6" />,
  }

  return (
    <svg
      aria-hidden="true"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  )
}

function ProductCard({ product, onAdd, onOpen }) {
  return (
    <article className="product-card">
      <button className="product-image-button" onClick={() => onOpen(product)} aria-label={`View ${product.name}`}>
        <img src={product.image} alt={product.name} />
      </button>
      <div className="product-card-copy">
        <span className="product-category">{product.category}</span>
        <button className="product-name" onClick={() => onOpen(product)}>{product.name}</button>
        <div className="rating" aria-label={`${product.rating} out of 5 stars`}>
          <span>{product.rating.toFixed(1)}</span>
          <span className="stars">★★★★★</span>
          <span className="review-count">({product.reviews.toLocaleString()})</span>
        </div>
        <div className="price-line">
          <span className="currency">$</span>
          <span className="price">{product.price.toFixed(2)}</span>
          {product.oldPrice && <span className="old-price">${product.oldPrice.toFixed(2)}</span>}
        </div>
        <p className="delivery-copy">FREE delivery <strong>Tomorrow</strong></p>
        <button className="add-button" onClick={() => onAdd(product)}>Add to cart</button>
      </div>
    </article>
  )
}

function App() {
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')
  const [cart, setCart] = useState([])
  const [overlay, setOverlay] = useState(null)
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [userName, setUserName] = useState('')
  const [loginName, setLoginName] = useState('')
  const [loginDestination, setLoginDestination] = useState('account')
  const [orderPlaced, setOrderPlaced] = useState(false)
  const [orderNumber, setOrderNumber] = useState('')

  const visibleProducts = useMemo(() => {
    const query = search.trim().toLowerCase()
    return products.filter((product) => {
      const matchesCategory = activeCategory === 'All' || product.category === activeCategory
      const matchesSearch = !query || `${product.name} ${product.category} ${product.description}`.toLowerCase().includes(query)
      return matchesCategory && matchesSearch
    })
  }, [activeCategory, search])

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0)
  const cartTotal = cart.reduce((total, item) => total + item.price * item.quantity, 0)

  function addToCart(product) {
    setCart((items) => {
      const found = items.find((item) => item.id === product.id)
      return found
        ? items.map((item) => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)
        : [...items, { ...product, quantity: 1 }]
    })
  }

  function updateQuantity(productId, amount) {
    setCart((items) => items
      .map((item) => item.id === productId ? { ...item, quantity: item.quantity + amount } : item)
      .filter((item) => item.quantity > 0))
  }

  function startCheckout() {
    if (!cart.length) return
    setOrderPlaced(false)
    if (userName) {
      setOverlay('checkout')
    } else {
      setLoginDestination('checkout')
      setOverlay('login')
    }
  }

  function submitLogin(event) {
    event.preventDefault()
    const name = loginName.trim()
    if (!name) return
    setUserName(name)
    setOverlay(loginDestination)
    setLoginDestination('account')
  }

  function placeDemoOrder() {
    setOrderNumber(`BM-${Date.now().toString().slice(-6)}`)
    setOrderPlaced(true)
    setCart([])
  }

  function closeOverlay() {
    setOverlay(null)
    setSelectedProduct(null)
  }

  function selectCategory(category) {
    setActiveCategory(category)
    setSearch('')
    document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <div className="app-shell">
      <header className="site-header">
        <div className="top-header">
          <a className="brand" href="#" onClick={(event) => { event.preventDefault(); selectCategory('All') }} aria-label="Bamazon home">
            <span className="brand-mark">b</span>
            <span className="brand-word">bamazon<span>.</span></span>
          </a>
          <button className="delivery-location" onClick={() => setOverlay('location')}>
            <Icon name="pin" size={19} />
            <span><small>Deliver to</small><strong>New York 10001</strong></span>
          </button>
          <form className="search-bar" onSubmit={(event) => { event.preventDefault(); document.getElementById('shop')?.scrollIntoView({ behavior: 'smooth' }) }}>
            <label className="sr-only" htmlFor="site-search">Search products</label>
            <select aria-label="Search category" value={activeCategory} onChange={(event) => setActiveCategory(event.target.value)}>
              <option value="All">All</option>
              {categories.map((category) => <option key={category} value={category}>{category}</option>)}
            </select>
            <input id="site-search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search Bamazon" />
            <button type="submit" aria-label="Search"><Icon name="search" size={22} /></button>
          </form>
          <button className="account-button" onClick={() => { setLoginDestination('account'); setOverlay(userName ? 'account' : 'login') }}>
            <Icon name="user" size={21} />
            <span><small>Hello{userName ? `, ${userName}` : ', sign in'}</small><strong>Account</strong></span>
          </button>
          <button className="orders-button" onClick={() => { setLoginDestination('orders'); setOverlay(userName ? 'orders' : 'login') }}>
            <small>Returns</small><strong>&amp; Orders</strong>
          </button>
          <button className="cart-button" onClick={() => setOverlay('cart')} aria-label={`Cart, ${cartCount} items`}>
            <span className="cart-count">{cartCount}</span><Icon name="cart" size={28} /><strong>Cart</strong>
          </button>
        </div>
        <nav className="main-nav" aria-label="Main navigation">
          <button className="all-menu" onClick={() => setOverlay('departments')}><Icon name="menu" size={18} /> All</button>
          {['Today’s Deals', 'Best Sellers', 'Home & Living', 'Electronics', 'Fashion', 'Books', 'Customer Service'].map((item) => (
            <button key={item} onClick={() => selectCategory(item === 'Home & Living' ? 'Home' : item === 'Today’s Deals' || item === 'Best Sellers' || item === 'Customer Service' ? 'All' : item)}>{item}</button>
          ))}
          <span className="nav-promo">A little something for every day</span>
        </nav>
      </header>

      <main>
        <section className="hero-banner">
          <div className="hero-content">
            <span className="eyebrow">BAMAZON PICKS</span>
            <h1>Everyday deals<br />for every day.</h1>
            <p>Shop favorites across home, tech, style, and more.</p>
            <button className="hero-cta" onClick={() => selectCategory('All')}>Shop all deals <Icon name="arrow" size={18} /></button>
          </div>
          <div className="hero-art" role="img" aria-label="A bright, comfortable home interior" />
        </section>

        <section className="category-section" aria-label="Shop by category">
          <h2>Shop popular departments</h2>
          <div className="category-strip">
            {[
              { name: 'Home', image: 'photo-1616486338812-3dadae4b4ace' },
              { name: 'Electronics', image: 'photo-1498049794561-7780e7231661' },
              { name: 'Fashion', image: 'photo-1483985988355-763728e1935b' },
              { name: 'Beauty', image: 'photo-1601049541289-9b1b7bbbfe19' },
              { name: 'Books', image: 'photo-1507842217343-583bb7270b66' },
            ].map((category) => (
              <button className="category-card" key={category.name} onClick={() => selectCategory(category.name)}>
                <strong>{category.name}</strong>
                <img src={`https://images.unsplash.com/${category.image}?auto=format&fit=crop&w=420&q=80`} alt="" />
                <span>Shop now</span>
              </button>
            ))}
          </div>
        </section>

        <section className="shop-section" id="shop">
          <div className="section-heading">
            <div>
              <h2>{search ? `Results for “${search}”` : activeCategory === 'All' ? 'Popular products' : `Shop ${activeCategory}`}</h2>
            </div>
            <button className="text-link" onClick={() => { setActiveCategory('All'); setSearch('') }}>See all products <Icon name="arrow" size={16} /></button>
          </div>
          {visibleProducts.length ? (
            <div className="product-grid">
              {visibleProducts.map((product) => (
                <ProductCard key={product.id} product={product} onAdd={addToCart} onOpen={setSelectedProduct} />
              ))}
            </div>
          ) : (
            <div className="empty-results"><span>Nothing on this shelf just yet.</span><p>Try another search or explore all our finds.</p><button className="add-button" onClick={() => { setActiveCategory('All'); setSearch('') }}>See all products</button></div>
          )}
        </section>

      </main>

      <footer className="site-footer">
        <button className="back-top" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>Back to top</button>
        <div className="footer-main">
          <a className="brand footer-brand" href="#" onClick={(event) => { event.preventDefault(); window.scrollTo({ top: 0, behavior: 'smooth' }) }}><span className="brand-mark">b</span><span className="brand-word">bamazon<span>.</span></span></a>
          <div className="footer-links"><button onClick={() => setOverlay('about')}>About us</button><button onClick={() => setOverlay('help')}>Help center</button><button onClick={() => setOverlay('privacy')}>Privacy</button></div>
        </div>
        <div className="footer-bottom">© 2026 Bamazon · A frontend practice project. Demo checkout only.</div>
      </footer>

      {overlay && (
        <div className="overlay-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) closeOverlay() }}>
          <section className={`dialog ${overlay === 'cart' ? 'cart-dialog' : ''}`} role="dialog" aria-modal="true" aria-label={overlay === 'cart' ? 'Your cart' : 'Store dialog'}>
            <button className="dialog-close" onClick={closeOverlay} aria-label="Close"><Icon name="close" /></button>
            {overlay === 'cart' && (
              <>
                <span className="eyebrow">YOUR BAG</span><h2>Your cart <span className="muted">({cartCount})</span></h2>
                {cart.length ? <><div className="cart-items">{cart.map((item) => (
                  <div className="cart-item" key={item.id}>
                    <img src={item.image} alt="" />
                    <div className="cart-item-info"><strong>{item.name}</strong><span>${item.price.toFixed(2)}</span><div className="quantity-control"><button onClick={() => updateQuantity(item.id, -1)} aria-label={`Remove one ${item.name}`}><Icon name="minus" size={14} /></button><span>{item.quantity}</span><button onClick={() => updateQuantity(item.id, 1)} aria-label={`Add one ${item.name}`}><Icon name="plus" size={14} /></button></div></div>
                    <strong className="cart-line-total">${(item.price * item.quantity).toFixed(2)}</strong>
                  </div>
                ))}</div><div className="cart-total"><span>Subtotal</span><strong>${cartTotal.toFixed(2)}</strong></div><p className="demo-note">Taxes and delivery are simulated for this demo.</p><button className="primary-button full-button" onClick={startCheckout}>Continue to checkout <Icon name="arrow" size={17} /></button></>
                  : <div className="empty-cart"><div className="empty-cart-icon"><Icon name="cart" size={28} /></div><h3>Your bag is taking a little breather.</h3><p>Add something lovely to get started.</p><button className="primary-button" onClick={closeOverlay}>Keep browsing</button></div>}
              </>
            )}
            {overlay === 'login' && (
              <div className="login-content"><span className="eyebrow">WELCOME TO BAMAZON</span><div className="login-mark"><Icon name="user" size={25} /></div><h2>Sign in to continue.</h2><p>Sign in is simulated for this practice project. Enter a name to continue to checkout.</p><form onSubmit={submitLogin}><label htmlFor="login-name">Name for this demo</label><input id="login-name" value={loginName} onChange={(event) => setLoginName(event.target.value)} placeholder="e.g. Alex" autoComplete="off" required /><button className="primary-button full-button" type="submit">Continue <Icon name="arrow" size={17} /></button></form><small className="privacy-hint">No password or personal account is created.</small></div>
            )}
            {overlay === 'checkout' && (
              orderPlaced ? <div className="order-success"><div className="success-icon"><Icon name="check" size={34} /></div><span className="eyebrow">ORDER CONFIRMED</span><h2>Thanks, {userName}!</h2><p>Your pretend order is all set. No payment was taken.</p><div className="order-number">DEMO ORDER · {orderNumber}</div><button className="primary-button" onClick={closeOverlay}>Back to shopping</button></div>
                : <div className="checkout-content"><span className="eyebrow">ALMOST YOURS</span><h2>Checkout</h2><p className="demo-note">You’re signed in as <strong>{userName}</strong>. This is a visual demo—no real payment will be made.</p><div className="checkout-summary"><span>{cartCount} {cartCount === 1 ? 'item' : 'items'}</span><strong>${cartTotal.toFixed(2)}</strong></div><div className="fake-payment"><span className="fake-card">••••</span><span>Demo payment method</span><span className="fake-pill">SIMULATED</span></div><button className="primary-button full-button" onClick={placeDemoOrder}>Place demo order <Icon name="arrow" size={17} /></button><button className="back-link" onClick={() => setOverlay('cart')}>Return to cart</button></div>
            )}
            {overlay === 'account' && <div className="simple-dialog-content"><span className="eyebrow">YOUR ACCOUNT</span><h2>Hi, {userName}.</h2><p>You’re signed in for this browser session. This practice storefront doesn’t save account data.</p><button className="primary-button" onClick={() => { setUserName(''); setOverlay(null) }}>Sign out</button></div>}
            {overlay === 'orders' && <div className="simple-dialog-content"><span className="eyebrow">YOUR ORDERS</span><h2>Nothing here yet.</h2><p>Demo orders are not saved, but you can place a simulated order from your cart.</p><button className="primary-button" onClick={() => setOverlay('cart')}>Open your cart</button></div>}
            {overlay === 'departments' && <div className="simple-dialog-content"><span className="eyebrow">EXPLORE</span><h2>Shop by department</h2><div className="department-list">{categories.map((category) => <button key={category} onClick={() => { closeOverlay(); selectCategory(category) }}>{category}<Icon name="arrow" size={16} /></button>)}</div></div>}
            {overlay === 'location' && <div className="simple-dialog-content"><span className="eyebrow">DELIVERY LOCATION</span><h2>Shopping near New York</h2><p>Delivery location is a visual demo and isn’t used for shipping.</p><button className="primary-button" onClick={closeOverlay}>Sounds good</button></div>}
            {['about', 'help', 'privacy'].includes(overlay) && <div className="simple-dialog-content"><span className="eyebrow">BAMAZON MARKETPLACE</span><h2>{overlay === 'about' ? 'A brighter everyday.' : overlay === 'help' ? 'Here to help.' : 'Your privacy matters.'}</h2><p>This frontend-only practice project uses sample product content. It doesn’t process real orders or store personal account details.</p><button className="primary-button" onClick={closeOverlay}>Got it</button></div>}
          </section>
        </div>
      )}

      {selectedProduct && (
        <div className="overlay-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelectedProduct(null) }}>
          <section className="dialog product-dialog" role="dialog" aria-modal="true" aria-label={selectedProduct.name}>
            <button className="dialog-close" onClick={() => setSelectedProduct(null)} aria-label="Close"><Icon name="close" /></button>
            <img className="detail-image" src={selectedProduct.image} alt={selectedProduct.name} />
            <div className="detail-copy"><span className="eyebrow">{selectedProduct.category}</span><h2>{selectedProduct.name}</h2><div className="rating"><span>{selectedProduct.rating.toFixed(1)}</span><span className="stars">★★★★★</span><span className="review-count">({selectedProduct.reviews.toLocaleString()} reviews)</span></div><p>{selectedProduct.description}</p><strong className="detail-price">${selectedProduct.price.toFixed(2)}</strong><p className="delivery-copy">FREE delivery <strong>Tomorrow</strong></p><button className="primary-button full-button" onClick={() => { addToCart(selectedProduct); setSelectedProduct(null); setOverlay('cart') }}>Add to cart</button></div>
          </section>
        </div>
      )}
    </div>
  )
}

export default App
