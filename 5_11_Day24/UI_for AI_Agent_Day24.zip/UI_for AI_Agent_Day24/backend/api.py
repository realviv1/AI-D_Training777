import json
import logging
import os
from pathlib import Path
from typing import Literal

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from openai import OpenAI
from pydantic import BaseModel, Field

from .tools import reserve_book, search_books

load_dotenv(Path(__file__).resolve().parent / ".env")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

MODEL = "openai/gpt-4o-mini"
TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_books",
            "description": "Search the library catalog by title, author, or category.",
            "parameters": {
                "type": "object",
                "properties": {"keyword": {"type": "string"}},
                "required": ["keyword"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "reserve_book",
            "description": "Reserve an available library book for a customer.",
            "parameters": {
                "type": "object",
                "properties": {
                    "book_id": {"type": "integer"},
                    "customer_name": {"type": "string"},
                },
                "required": ["book_id", "customer_name"],
            },
        },
    },
]

SYSTEM_PROMPT = (
    "You are a helpful library assistant. Use the catalog tools when users ask "
    "about books or reservations. Before making a reservation, make sure the "
    "user has explicitly confirmed it in the conversation, and that you have "
    "their name and the book. Never claim an action succeeded unless the tool "
    "confirms it. Keep answers clear and concise."
)

app = FastAPI(title="Library Assistant")
frontend_path = Path(__file__).resolve().parent.parent / "frontend"
app.mount("/assets", StaticFiles(directory=frontend_path), name="assets")


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=12000)


class ChatRequest(BaseModel):
    messages: list[ChatMessage] = Field(min_length=1, max_length=40)


class ChatResponse(BaseModel):
    reply: str


def run_tool(name: str, arguments: dict):
    if name == "search_books":
        return search_books(arguments["keyword"])
    if name == "reserve_book":
        return reserve_book(arguments["book_id"], arguments["customer_name"])
    raise ValueError(f"Unknown tool: {name}")


@app.get("/", include_in_schema=False)
def home():
    return FileResponse(frontend_path / "index.html")


@app.post("/api/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        raise HTTPException(
            status_code=503,
            detail="The assistant is not configured. Add OPENROUTER_API_KEY to backend/.env.",
        )

    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=api_key,
    )
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages.extend(message.model_dump() for message in request.messages)

    try:
        for _ in range(6):
            response = client.chat.completions.create(
                model=MODEL,
                messages=messages,
                tools=TOOLS,
            )
            assistant_message = response.choices[0].message
            messages.append(assistant_message.model_dump(exclude_none=True))

            if not assistant_message.tool_calls:
                return ChatResponse(reply=assistant_message.content or "")

            for tool_call in assistant_message.tool_calls:
                name = tool_call.function.name
                arguments = json.loads(tool_call.function.arguments)
                result = run_tool(name, arguments)
                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": json.dumps(result),
                    }
                )
    except Exception as error:
        logger.exception("Assistant request failed")
        raise HTTPException(
            status_code=502,
            detail="The assistant could not complete the request. Please try again.",
        ) from error

    raise HTTPException(
        status_code=502,
        detail="The assistant reached its tool-call limit. Please try again.",
    )
