const form = document.querySelector("#chatForm");
const input = document.querySelector("#messageInput");
const sendButton = document.querySelector("#sendButton");
const conversation = document.querySelector("#conversation");
const welcome = document.querySelector("#welcome");
const messagesContainer = document.querySelector("#messages");
const sidebar = document.querySelector("#sidebar");
const backdrop = document.querySelector("#backdrop");

const history = [];
let waiting = false;

function resizeInput() {
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 150)}px`;
  sendButton.disabled = waiting || !input.value.trim();
}

function scrollToBottom() {
  requestAnimationFrame(() => conversation.scrollTo({ top: conversation.scrollHeight, behavior: "smooth" }));
}

function addMessage(role, text, { loading = false, error = false } = {}) {
  const row = document.createElement("article");
  row.className = `message-row ${role}`;

  if (role === "assistant") {
    const avatar = document.createElement("div");
    avatar.className = "message-avatar";
    avatar.setAttribute("aria-label", "Folio");
    avatar.innerHTML = '<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M4.5 5.5c2.8-.9 5.3-.5 7.5 1.1v12c-2.2-1.6-4.7-2-7.5-1.1v-12Z"/><path d="M19.5 5.5c-2.8-.9-5.3-.5-7.5 1.1v12c2.2-1.6 4.7-2 7.5-1.1v-12Z"/></svg>';
    row.append(avatar);
  }

  const content = document.createElement("div");
  content.className = "message-content";
  if (role === "assistant") {
    const author = document.createElement("div");
    author.className = "message-author";
    author.textContent = "Folio";
    content.append(author);
  }

  const messageText = document.createElement("div");
  messageText.className = `message-text${error ? " error-text" : ""}`;
  if (loading) {
    messageText.innerHTML = '<div class="typing-dots" aria-label="Folio is thinking"><span></span><span></span><span></span></div>';
  } else {
    messageText.textContent = text;
  }
  content.append(messageText);
  row.append(content);
  messagesContainer.append(row);
  scrollToBottom();
  return row;
}

async function submitMessage(text) {
  const message = text.trim();
  if (!message || waiting) return;

  welcome.hidden = true;
  addMessage("user", message);
  history.push({ role: "user", content: message });
  input.value = "";
  resizeInput();

  waiting = true;
  sendButton.disabled = true;
  const pending = addMessage("assistant", "", { loading: true });

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: history }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Something went wrong. Please try again.");
    pending.remove();
    addMessage("assistant", data.reply);
    history.push({ role: "assistant", content: data.reply });
  } catch (error) {
    pending.remove();
    addMessage("assistant", error.message || "Unable to reach the assistant. Please try again.", { error: true });
  } finally {
    waiting = false;
    resizeInput();
    input.focus();
  }
}

function startNewChat() {
  history.length = 0;
  messagesContainer.replaceChildren();
  welcome.hidden = false;
  input.value = "";
  resizeInput();
  input.focus();
  setSidebar(false);
}

function setSidebar(open) {
  sidebar.classList.toggle("open", open);
  backdrop.classList.toggle("show", open);
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  submitMessage(input.value);
});

input.addEventListener("input", resizeInput);
input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

document.querySelectorAll(".suggestion").forEach((button) => {
  button.addEventListener("click", () => submitMessage(button.dataset.prompt));
});
document.querySelector("#newChat").addEventListener("click", startNewChat);
document.querySelector("#openSidebar").addEventListener("click", () => setSidebar(true));
document.querySelector("#closeSidebar").addEventListener("click", () => setSidebar(false));
backdrop.addEventListener("click", () => setSidebar(false));
document.querySelector("#shareChat").addEventListener("click", async () => {
  if (!navigator.clipboard) return;
  const transcript = history.map((message) => `${message.role === "user" ? "You" : "Folio"}: ${message.content}`).join("\n\n");
  try {
    await navigator.clipboard.writeText(transcript || "Chat with Folio, your City Library assistant.");
  } catch {
    addMessage("assistant", "I couldn't access the clipboard. You can still select and copy this conversation.");
  }
});
document.addEventListener("keydown", (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    startNewChat();
  }
  if (event.key === "Escape") setSidebar(false);
});

resizeInput();
