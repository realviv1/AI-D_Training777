# Folio Library Assistant

A responsive chat interface for the library assistant. FastAPI serves the frontend and exposes `/api/chat`; the backend uses OpenRouter and the book tools in `backend/tools.py`.

## Run locally

1. Install Python 3.10 or later.
2. From the project root, install the backend dependencies:

   ```powershell
   py -m pip install -r backend\requirements.txt
   ```

3. Add your OpenRouter key to `backend\.env`:

   ```text
   OPENROUTER_API_KEY=your-key-here
   ```

4. Start the server from the project root:

   ```powershell
   py -m uvicorn backend.api:app --reload
   ```

5. Open <http://127.0.0.1:8000>.

The frontend uses plain HTML, CSS, and JavaScript, so no Node.js build step is required.
